##########################################################################
# Program:              GGPLOT2-Advanced: Case 3 - Forest plot
# Lang/Vers:            R
# Packages:             dplyr
#                       forestplot
# Author:               Emily Cheng     
# Date:                 18Aug2022     
##########################################################################

# Prep workspace -------------------------------------------------------------

library(dplyr)
library(forestplot)

# Import data ------------------------------------------------------------

df_for_plot <- readRDS("forest_data.rds")

labeltext <- df_for_plot %>% 
  select(row_text,count,hr_text,lower_text,upper_text,pvalue_text)

# One basic forest plot ---------------------------------------------------

forestplot(x=df_for_plot,
          labeltext=labeltext,
          mean=hr, 
          lower=lower, 
          upper=upper)
                
p <- forestplot(x=df_for_plot,
                labeltext=labeltext,
                mean=hr, 
                lower=lower, 
                upper=upper,     
                
                # change graph element position, "left", "right", or from 1 to (ncol(labeltext) + 1)  
                graph.pos=3, 
                
                # reference line, 1 or 0
                zero=1,
                
                # change all box size to the same,
                boxsize=0.4, 
                
                # arrow and vertices
                clip=c(0,2.5),
                ci.vertices=TRUE,
                
                # x axis,
                xticks=c(0,0.5,1,1.5,2.0,2.5),
                xlab="DummyA            DummyB            ",
                
                # Other
                col=fpColors(box="royalblue",lines='royalblue'),
                graphwidth=unit(3,"inches"),
                colgap=unit(3,"mm"),
                title="Case 3 Forest Plot"
                )    
p

# Save plot: Option 1
# grid.draw.gforge_forestplot <- function(x){
#   forestplot:::print.gforge_forestplot(x, newpage = FALSE)
# }
# ggsave("Case3_forestplot.png",plot=p,width=9,height=8,units="in",dpi=300)

# Save plot: Option 2
# png(filename="Case3_forestplot.png", width=9, height=8,units="in",res=100)
# p
# dev.off() 
