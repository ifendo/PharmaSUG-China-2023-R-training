##########################################################################
# Program:              GGPLOT2-Advanced: Case 1 - line plot
# Lang/Vers:            R
# Packages:             ggplot2, dplyr,haven
#                       RColorBrewer
#                       patchwork
# Author:               Emily Cheng     
# Date:                 18Aug2022     
##########################################################################

# Prep workspace ---------------------------------------------------------

library(ggplot2)
library(dplyr)
library(haven)

# Import data ------------------------------------------------------------

rspsum <- read_sas("rspsum.sas7bdat") %>%
  mutate(ytext=ifelse(TRT=="Placebo",0,ifelse(TRT=="Low Dose",-3, -6)),
         TRTN=ifelse(TRT=="Placebo",0,ifelse(TRT=="Low Dose",1, 2)))
  
rspsum$AVISIT <- factor(rspsum$AVISIT,
                        levels=c('Baseline', 'Week 2', 'Week 4', 'Week 6', 'Week 8', 'Week 12','Week 16','Week 20'))
rspsum$TRT <- factor(rspsum$TRT,
                        levels=c('Placebo', 'Low Dose', 'High Dose'))

p <- ggplot(data=rspsum, aes(y=RESPONSE, x=AVISIT, group=TRT, color = TRT)) +
        geom_line(aes(linetype=TRT) ) +
        geom_point(aes(shape=TRT) ) +
        labs(title = 'Case 1 Response Rates Overtime',
             x = 'Visit (Weeks)',
             y = '% Response Rate',
             shape='Treatment',
             linetype='Treatment', 
             color='Treatment') +
        theme_bw()


# 2.1 Color modification ---------------------------------------------------------------

p + scale_color_manual(values=c("royalblue","orange","red"))

p + scale_color_brewer(palette="Blues",direction=1)

library("RColorBrewer")
mypalette <- brewer.pal(5, "Blues")
mypalette[3:5]
p + scale_color_manual(values=mypalette[3:5])


# 2.2 Text modification ---------------------------------------------------

p <- p + scale_color_manual(values=c("royalblue","orange","red"))

p + geom_text(aes(y=ytext,x=AVISIT,label=paste0("N=",COUNT)),size=3) +
    scale_y_continuous(limits=c(-10,70),breaks=seq(-10,70,by=10)) 

p + geom_text(aes(y=ytext,x=AVISIT,label=paste0("N=",COUNT)),size=3) +
    scale_y_continuous(limits=c(-10,70),breaks=seq(-10,70,by=10))+
    annotate("text",x=0.6,y=0 ,label="PLB", size=3, color="royalblue") +
    annotate("text",x=0.6,y=-3,label="LOW", size=3, color="orange") + 
    annotate("text",x=0.6,y=-6,label="HIGH",size=3, color="red")


# 2.3 Legend --------------------------------------------------------------

p <- p + geom_text(aes(y=ytext,x=AVISIT,label=paste0("N=",COUNT)),size=3, show.legend = FALSE) +
  scale_y_continuous(limits=c(-10,70),breaks=seq(-10,70,by=10))  +
  annotate("text",x=0.6,y=0 ,label="PLB", size=3, color="royalblue") +
  annotate("text",x=0.6,y=-3,label="LOW", size=3, color="orange") + 
  annotate("text",x=0.6,y=-6,label="HIGH",size=3, color="red")

p <- p + theme(legend.position=c(0.9,0.85))

# 2.4 final touch ---------------------------------------------------------

p + theme(panel.grid.major=element_blank(),
          panel.grid.minor=element_blank(), 
          axis.title.x = element_text(size=12,face="bold")) +
    geom_hline(yintercept=35,color="grey",linetype=2)

# Solution 2 --------------------------------------------------------------

library(patchwork)

p1 <- ggplot(data=rspsum, aes(y=RESPONSE, x=AVISIT, group=TRT, color = TRT)) +
        geom_line(aes(linetype=TRT) ) +
        geom_point(aes(shape=TRT) ) +
        labs(title = 'Case 1 Response Rates Overtime',
             x = 'Visit (Weeks)',
             y = '% Response Rate',
             shape='Treatment',
             linetype='Treatment', 
             color='Treatment') +
        theme_bw()+
        scale_color_manual(values=c("royalblue","orange","red"))+
        theme(legend.position=c(0.9,0.85),
              panel.grid.major=element_blank(),
              panel.grid.minor=element_blank(), 
              axis.title.x = element_text(size=12, face="bold")) +
        geom_hline(yintercept=35,color="grey",linetype=2)

p2 <- ggplot(rspsum,aes(x=AVISIT,color=TRT)) +
  geom_text(aes(y=reorder(TRT,2-TRTN),label=COUNT),show.legend=F,size=3)+
  labs(title="No. of Subjects")+
  scale_color_manual(values=c("royalblue","orange","red"))+
  theme_classic()+
  theme(axis.line=element_blank(),
        axis.ticks=element_blank(),
        axis.title=element_blank(),
        axis.text.x=element_blank(),
        title=element_text(size=8,face="plain"))

p1 / p2 +  plot_layout(heights = c(8, 2))

# ggsave("Case1_lineplot.png",plot=last_plot(),width=9,height=6,units="in",dpi=300)

