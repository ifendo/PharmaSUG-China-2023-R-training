##########################################################################
# Program:              GGPLOT2-Advanced: Case 2 - KM plot
# Lang/Vers:            R
# Packages:             survival, survminer,
#                       dplyr,haven
#                       patchwork
# Author:               Emily Cheng     
# Date:                 18Aug2022     
##########################################################################

# Prep workspace -------------------------------------------------------------

# Demo

library(survival)
library(survminer)

# Survivial Object
time <- c(5, 6, 2, 4, 4)
event <- c(1, 0, 0, 1, 1)

Surv(time, event)

sobj <- Surv(time, event)
class(sobj)
str(sobj)
summary(sobj)

# Survival curves
fit <- survfit(Surv(time,event)~1)
class(fit)
str(fit)

?survfit.object

# ggsurvplot()
indata <- data.frame(time=c(5, 6, 2, 4, 4),event=c(1, 0, 0, 1, 1))
fit <- survfit(Surv(indata$time,indata$event)~1)

ggsurvplot(fit,
           indata)

fit <- survfit(Surv(time,event)~1,data=indata)
ggsurvplot(fit)

ggsurvplot(fit,
           data=indata,
           conf.int = FALSE,
           risk.table = TRUE,
           legend = "none")


# Case 2 ------------------------------------------------------------------


# Prep workspace ----------------------------------------------------------

library(dplyr)
library(haven)
library(survival)
library(survminer)

adtte <- read_sas("adtte.sas7bdat") %>% 
  filter(PARAMCD =="TTDE" & SAFFL == "Y") %>% 
  select(USUBJID, PARAM, AVAL, TRTAN, TRTA, CNSR)
  
# Surv Object -------------------------------------------------------------

sobj <- Surv(adtte$AVAL,adtte$CNSR==0)

sobj <- Surv(adtte$AVAL,1-adtte$CNSR)

sobj[1:10]

# survift -----------------------------------------------------------------

fit <- survfit(Surv(AVAL, 1-CNSR) ~ TRTAN, data=adtte)

# ggsurvplot --------------------------------------------------------------

ggsurvplot(fit)

ggsurvplot(fit, risk.table=T)

?ggsurvplot_arguments

p <- ggsurvplot(fit,
                
                censor.shape = c(3), 
                censor.size = 2.5, 
                
                linetype = "strata",
                
                surv.median.line = "hv",

                xlim = c(0, 200),
                break.time.by = 20,
                surv.scale = "percent",  
                
                xlab = "Time to First Dermatologic Event (Days)",
                ylab = "Subjects without event",
                
                risk.table = TRUE, 
                risk.table.title = "Subjects at risk",
                tables.theme = theme_cleantable(),

                legend.labs = c("Placebo", "Low Dose", "High Dose"), 
                legend = 'bottom',
                legend.title = 'Treatment'
                )

p$plot <- p$plot+
  geom_hline(yintercept=0.5,linetype="dashed") +
  labs(title='Case 2 KM Plot')

# Save Plot: option 1
# grid.draw.ggsurvplot <- function(x){
#   survminer:::print.ggsurvplot(x, newpage = FALSE)
# }
# ggsave("Case2_KMplot.png",plot=p,width=9,height=6,units="in",dpi=300)

# Save Plot: option 2
# png(filename="Case2_KMplot.png", width=9, height=6,units="in",res=100)
# p
# dev.off()