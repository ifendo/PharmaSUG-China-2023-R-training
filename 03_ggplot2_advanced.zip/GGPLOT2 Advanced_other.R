library(esquisse)

esquisser(rspsum)

library(ggThemeAssist)

p <- ggplot(data=rspsum, aes(y=RESPONSE, x=AVISIT, group=TRT, color = TRT)) +
  geom_line(aes(linetype=TRT) ) +
  geom_point(aes(shape=TRT) ) +
  labs(title = 'Case 1 Response Rates Overtime',
       x = 'Visit (Weeks)',
       y = '% Response Rate',
       shape='Treatment',
       linetype='Treatment', 
       color='Treatment') +
  theme_bw()

ggThemeAssist::ggThemeAssistGadget(p)
# p + theme(legend.position = "bottom", legend.direction = "horizontal")