##########################################################################
# Program:              GGPLOT2-Intermediate
# Lang/Vers:            R
# Packages:             ggplot2, dplyr,haven
# Author:               Emily Cheng     
# Date:                 18Aug2022     
##########################################################################

# Prep workspace ---------------------------------------------------------

library(ggplot2)
library(dplyr)
library(haven)

# Import data ------------------------------------------------------------

adsl <- read_sas("adsl.sas7bdat") %>% 
        select (USUBJID, TRT01P, AGE, AGEGR1, SEX, RACE, HEIGHTBL, WEIGHTBL, BMIBL)

# 3. Build Basic Scatter Plot ---------------------------------------------

ggplot(data = adsl, aes(x = HEIGHTBL, y = WEIGHTBL)) +
  geom_point() +
  labs(title='Plot 1.1')

# 4. Aesthetic Mapping ----------------------------------------------------

ggplot(data = adsl, aes(x = HEIGHTBL, y = WEIGHTBL, color = SEX)) +
  geom_point() +
  labs(title='Plot 1.2')

ggplot(data = adsl, aes(x = HEIGHTBL, y = WEIGHTBL, color=SEX, shape = TRT01P)) +
  geom_point() +
  labs(title='Plot 1.3')

# 5. Modifying Aesthetics -------------------------------------------------

ggplot(data = adsl, aes(x = HEIGHTBL, y = WEIGHTBL)) +
  geom_point() +
  scale_x_continuous(name = "Baseline Height", breaks = seq(120, 200, by = 20)) +
  scale_y_continuous(name = "Baseline Weight", breaks = seq(30, 120, by = 10)) +
  labs(title='Plot 1.4')

ggplot(data = adsl, aes(x = HEIGHTBL, y = WEIGHTBL, color = SEX)) +
  geom_point() +
  scale_x_continuous(name = "Baseline Height", breaks = seq(120, 200, by = 20)) +
  scale_y_continuous(name = "Baseline Weight", breaks = seq(30, 120, by = 10)) +
  scale_color_manual(name = "Sex", values=c("red","blue"), labels = c("Female","Male")) +
  labs(title='Plot 1.5')

# 6. Fixed Attributes -----------------------------------------------------

ggplot(data = adsl, aes(x = HEIGHTBL, y = WEIGHTBL)) + 
  geom_point(shape = "plus", color = "blue") +
  labs(title='Plot 1.6')

# 7. Geometries -----------------------------------------------------------

adsl2 <- adsl %>% 
         filter(AGE <= 70 & HEIGHTBL <= 160)

ggplot(data = adsl2, aes(x = AGE, y = HEIGHTBL, shape = TRT01P)) +
  geom_point() +
  labs(title='Plot 2.1')

ggplot(data = adsl2, aes(x = AGE, y = HEIGHTBL, shape = TRT01P)) +
  geom_point(position = position_dodge(width = .9))+
  labs(title='Plot 2.2')

# 8. Themes ---------------------------------------------------------------

ggplot(data = adsl, aes(x = HEIGHTBL, y = WEIGHTBL)) +
  geom_point() +
  # theme_classic()
  theme_bw()+
  # theme_void()
  labs(title='Plot 1.8')
 
# 8. Themes - Title -------------------------------------------------------

ggplot(data = adsl, aes(x = HEIGHTBL, y = WEIGHTBL, color = SEX)) +
  geom_point() +
  scale_x_continuous(name = "Baseline Height", breaks = seq(140, 220, by = 10)) +
  scale_y_continuous(name = "Baseline Weight", breaks = seq(40, 200, by = 10)) +
  scale_color_manual(name = "Sex", values=c("red","blue"), labels = c("Female","Male")) + 
  labs(title = "Plot 1.9 Scatter Plot of Baseline Height vs. Baseline Weight")

# 8. Themes - Other -------------------------------------------------------
ggplot(data = adsl, aes(x = HEIGHTBL, y = WEIGHTBL, color = SEX)) +
  geom_point() +
  scale_x_continuous(breaks = seq(140, 220, by = 10)) +
  scale_y_continuous(breaks = seq(40, 200, by = 10)) +
  scale_color_manual(values=c("red","blue"), labels = c("Female","Male")) + 
  labs(title = "Plot 1.9 Scatter Plot of Baseline Height vs. Baseline Weight",
       x     = "Baseline Height",
       y     ="Baseline Weight",
       color ="Sex")

# 9. Coordinates, Statistics and Facets -----------------------------------

ggplot(data = adsl, aes(x = HEIGHTBL, y = WEIGHTBL)) +
  geom_point()
  
ggplot(data = adsl, aes(x = HEIGHTBL, y = WEIGHTBL)) +
  geom_point() + 
  facet_wrap(~SEX, nrow=1) +
  labs(title="Plot 3.1")

ggplot(data = adsl, aes(x = HEIGHTBL, y = WEIGHTBL)) +
  geom_point() + 
  facet_wrap(SEX~AGEGR1) +
  labs(title="Plot 3.2")

ggplot(data = adsl, aes(x = HEIGHTBL, y = WEIGHTBL)) +
  geom_point() + 
  facet_grid(SEX~AGEGR1) +
  labs(title="Plot 3.3")

# facet_wrap() vs. facet_grid:
# Shows only plots with values vs. display plots even if some of them are empty.
adsl1 <- adsl %>% 
  filter(SEX=='F' | AGEGR1 != "<65")

ggplot(data = adsl1, aes(x = HEIGHTBL, y = WEIGHTBL)) +
  geom_point() + 
  facet_wrap(SEX~AGEGR1) +
  labs(title="Plot 3.2_1")

ggplot(data = adsl1, aes(x = HEIGHTBL, y = WEIGHTBL)) +
  geom_point() + 
  facet_grid(SEX~AGEGR1) +
  labs(title="Plot 3.3_1")


# Notes: Remove warning message about missing values

ggplot(data = adsl, aes(x = HEIGHTBL, y = WEIGHTBL)) +
  geom_point(na.rm=T)






# Common figures ----------------------------------------------------------
# Import data -------------------------------------------------------------

rspsum <- read_sas("rspsum.sas7bdat") 
rspsum$AVISIT <- factor(rspsum$AVISIT,
                        levels=c('Baseline', 'Week 2', 'Week 4', 'Week 6', 'Week 8', 'Week 12','Week 16','Week 20'))

# Case 1. Line Graphs ----------------------------------------------------------

# Question 1: which variable should I use for x-axis ?
ggplot(data = rspsum, aes(y=RESPONSE, x=AVISIT))

ggplot(data=rspsum, aes(y=RESPONSE, x=AVISIT)) + 
  geom_line()

# Question 2: why I need to use group=TRT aesthetic ? 
ggplot(data=rspsum, aes(y=RESPONSE, x=AVISIT, group = TRT)) + 
  geom_line()

ggplot(data=rspsum, aes(y=RESPONSE, x=AVISIT)) + 
  geom_line(aes(group = TRT))

# Add color aesthetic
ggplot(data=rspsum, aes(y=RESPONSE, x=AVISIT, group = TRT, color = TRT)) +
  geom_line()

# Add geom_point
ggplot(data=rspsum, aes(y=RESPONSE, x=AVISIT, group=TRT, color = TRT)) +
  geom_line() + 
  geom_point()

# Add linetype and shape aesthetic
ggplot(data=rspsum, aes(y=RESPONSE, x=AVISIT, group=TRT, color = TRT)) +
  geom_line(aes(linetype=TRT) ) +
  geom_point(aes(shape=TRT) )

# Add text info, and change theme
ggplot(data=rspsum, aes(y=RESPONSE, x=AVISIT, group=TRT, color = TRT)) +
  geom_line(aes(linetype=TRT) ) +
  geom_point(aes(shape=TRT) ) +
  labs(title = 'Case 1 Response Rates Overtime',
       x = 'Visit (Weeks)',
       y = '% Response Rate',
       shape='Treatment',
       linetype='Treatment', 
       color='Treatment') +
  theme_bw()

# Another option: using AVISITN as x axis
ggplot(data = rspsum, aes(y=RESPONSE, x=AVISITN, group = TRT, color = TRT))+
  geom_line(aes(linetype=TRT) ) +
  geom_point(aes(shape=TRT) )+
  scale_x_continuous(breaks=c(0,2,4,6,8,12,16,20),labels=c('Baseline', 'Week 2', 'Week 4', 'Week 6', 'Week 8', 'Week 12','Week 16','Week 20'))+
  labs(title = 'Case 1_1 Response Rates Overtime',
       x = 'Visit (Weeks)',
       y = '% Response Rate',
       shape='Treatment',
       linetype='Treatment', 
       color='Treatment') +
  theme_bw()

# Case 2. Bar Chart ------------------------------------------------------------

ggplot(data = diamonds, aes(x = cut)) + 
  geom_bar() 

rspsum <- read_sas("rspsum.sas7bdat") %>% 
  filter(AVISIT %in% c('Week 12','Baseline')) 

rspsum$AVISIT <- factor(rspsum$AVISIT,
                        levels=c('Baseline', 'Week 12'))

rspsum$TRT <- factor(rspsum$TRT,
                     levels=c('Placebo', 'Low Dose', 'High Dose'))

# fill aesthetic
ggplot(rspsum, aes(y=RESPONSE,  x=AVISIT, fill = TRT)) + 
  geom_bar() 

# stat = "identity", and position = 'dodge'
ggplot(rspsum, aes(y=RESPONSE,  x=AVISIT, fill = TRT)) + 
  geom_bar(stat = "identity") 

ggplot(rspsum, aes(y=RESPONSE,  x=AVISIT, fill = TRT)) + 
  geom_bar(stat = "identity", position = 'dodge', width = 0.75)  

# Add geom_text
ggplot(rspsum, aes(y=RESPONSE,  x=AVISIT, fill = TRT)) + 
  geom_bar(stat = "identity", position = 'dodge', width = 0.75) + 
  geom_text(aes(label = COUNT),
            position = position_dodge(width = 0.75))

ggplot(rspsum, aes(y=RESPONSE,  x=AVISIT, fill = TRT)) + 
  geom_bar(stat = "identity", position = 'dodge', width = 0.75) + 
  geom_text(aes(label = COUNT),
            position = position_dodge(width = 0.75),
            vjust = -0.5)

ggplot(rspsum, aes(y=RESPONSE,  x=AVISIT, fill = TRT)) + 
  geom_bar(stat = "identity", position = 'dodge', width = 0.75) + 
  geom_text(aes(label = COUNT),
            position = position_dodge(width = .75),
            vjust = -0.5, 
            size = 3)

# Change y-axis aesthetic, text info, theme
ggplot(rspsum, aes(y=RESPONSE,  x=AVISIT, fill = TRT)) + 
  geom_bar(stat = "identity", position = 'dodge', width = 0.75) + 
  geom_text(aes(label = COUNT),
            position = position_dodge(width = .75),
            vjust = -0.5, 
            size = 3)  +
  scale_y_continuous(limits=c(0,70), breaks=seq(0,70,10)) +
  labs(title = 'Case 2 Percent of Responders by Visit',
       x = 'Visit (Weeks)',
       y = 'Percent of Responders',
       fill ='Treatment') +
  theme_bw()

# Case 3. Box Plots ------------------------------------------------------------

chem <- read_sas("adlbc.sas7bdat") %>% 
  filter(TRTA=='Xanomeline High Dose' & PARAMCD=='PROT' & 0 <= AVISITN & AVISITN <= 26)

chem$AVISITN <- factor(chem$AVISITN)

ggplot(chem, aes(y=AVAL,  x=AVISITN)) +
  geom_boxplot() 

ggplot(chem, aes(y=AVAL,  x=AVISITN)) +  
  geom_boxplot(outlier.colour = "red", outlier.shape = 1) 

ggplot(chem, aes(y=AVAL,  x=AVISITN)) +
  geom_boxplot(outlier.colour = "red", outlier.shape = 1) +
  scale_y_continuous(limits=c(50, 90), breaks=seq(50, 90, 10)) +
  labs(title = 'Case 3 Box Plots of Total Protein (g/L) by Visits',
       x     = 'Visit (Weeks)',
       y     = 'Total Protain (g/L)') +
  theme()


# Note: If outlier points are overlaying on the top of the boxplot, 
#       outliers can be hidded by setting -  outlier.shape=NA

ggplot(diamonds, aes(x=cut, y=price)) +
  geom_boxplot(outlier.colour = "red", outlier.shape = 1) +
  labs(title = 'Summary of diamond price by cut',
       x     = 'Cut',
       y     = 'Price') +
  theme_bw()

ggplot(diamonds, aes(x=cut, y=price)) +
  geom_boxplot(outlier.colour = "red", outlier.shape = NA) +
  labs(title = 'Summary of diamond price by cut',
       x     = 'Cut',
       y     = 'Price') +
  theme_bw()

# Note: Adding treatment information
chem <- read_sas("adlbc.sas7bdat") %>% 
  filter(PARAMCD=='PROT' & 0 <= AVISITN & AVISITN <= 26)

chem$AVISITN <- factor(chem$AVISITN)
chem$TRTA <- factor(chem$TRTA,
                   levels=c('Placebo', 'Xanomeline Low Dose', 'Xanomeline High Dose'))

ggplot(chem, aes(y=AVAL,  x=AVISITN,color=TRTA)) +
  geom_boxplot(width=0.8) 
