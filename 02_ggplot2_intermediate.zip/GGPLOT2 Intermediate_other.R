library(esquisse)

esquisser(adsl)

library(ggThemeAssist)

p <- ggplot(data = adsl, aes(x = HEIGHTBL, y = WEIGHTBL,color=SEX)) +
  geom_point() +
  labs(title='Plot 1.1') 

ggThemeAssist::ggThemeAssistGadget(p)
# p + theme(legend.position = "bottom")


