

# https://github.com/knime-mpicbg/knime-scripting/wiki/R-server-for-knime

library(tidyverse)
library(haven)
##Sys.setlocale("LC_CTYPE", "Chinese")
##advs <- read_sas("~/data/advs.sas7bdat", encoding="utf8")
advs <- read_xpt("~/data/advs.xpt")


df_mean <- filter(advs, PARAM=="Systolic Blood Pressure (mmHg)") %>%
  select(TRTA,VISITNUM,VISIT,AVAL) %>%
  group_by(TRTA, VISITNUM, VISIT) %>%
  summarise(mean=mean(AVAL),n=n(),min=min(AVAL),max=max(AVAL),median=median(AVAL),std=sd(AVAL)) %>%
  pivot_longer(c(n,mean,median,min,max,std),names_to="stat",values_to="value") %>%
  group_by(VISITNUM, VISIT, stat) %>%
  pivot_wider(names_from="TRTA",values_from="value")


## https://stackoverflow.com/questions/43742824/convert-sas-proc-format-to-r

ff <- mutate(df_mean,statn=factor(stat,levels=c("n","mean","median","std","min","max"))) %>%
  arrange(VISITNUM, VISIT, statn, stat)

visitn <- ungroup(ff) %>%
  select(VISITNUM, VISIT) %>%
  distinct()
  
ff2 <- ungroup(ff) %>%
  mutate(AVISITN = factor(VISIT, levels=visitn$VISIT)) %>%
  select(-VISITNUM,-VISIT, -stat) %>%
  arrange(AVISITN,statn)
