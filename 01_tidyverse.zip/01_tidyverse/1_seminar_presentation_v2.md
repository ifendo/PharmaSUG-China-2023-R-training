<style>
body {
    overflow-y: auto !important;
}
</style>

Tidyverse Advanced 
========================================================
author: John Wang @ Caidya
date: Aug 3rd, 2023
autosize: true
width: 1400
height: 1000


Deep Dive into Tidyverse, ggplot2 and Shiny with Real Case Applications in Drug Development
========================================================
* Part 1, Tidyverse Advanced and ggplot2 Intermediate 
  + Tidyverse Advanced (John)
  + ggplot2 Intermediate (Emily)
<br />
<br />
* Part 2, ggplot2 Advanced and Shiny Advanced
  + ggplot2 Advanced (Emily)
  + Shiny Advanced (Jerry)

Tidyverse Advanced (Data Wrangling)
========================================================

* <span style="font-size: 1.1em;"> Datatypes: R <b> VS </b> SAS </span>

* <span style="font-size: 1.1em;"> Base R  <b> VS </b>  Tidyverse (consistent workflow) </span>
  
* <span style="font-size: 1.1em;"> The tidyverse is an opinionated collection of R packages  designed for data science. Core   packages included: </span>
  + Create **tidy data**: **tidyr**
  + Data **manipulation**: **dplyr**
  + A system for declaratively creating graphics: **ggplot2**  
  + Additional package: **haven** (import SAS datasets)  
<br /><br />
* <span style="font-size: 1.1em;">Example & Practice (20 min) </span>  
  + Example1.1  Set working directory and read dataset advs.xpt
  + Example1.2  List all *baseline* values in advs
  + Example1.3  Calculate BMI (Weight(kg)/Height(m) square)
  + Example1.4  Derive PP(pulse pressure:SYSBP-DIABP): <key>transpose long->wide  
      - Free Practice for all 4 examples.

R vs SAS 
========================================================
* SAS is commercial, R is free, open source
* SAS has tech support, R does not, **community**
* What makes R special?

|                   |R             | SAS                          | 
|------------------:|-------------:|----------------------------|
|**Case sensitive**     |A≠a                        |A=a          |
|**Commands separation** |';' or by a new line        |';'         |
|**program structure**  |expressions or assignments |data & proc  | 
|**commands execution** |any time| RUN statement at the end of each step is required to complete the execution of that step | 


R DATATYPES
========================================================
<br /><br />
Internally, SAS supports two data types:
* char (format/informat)
* num (date, time, datatime, format/informat)

<br />
R has a wide variety of data types, the frequently used ones are:

* **Vectors**
  + 6 classes of vectors :integer/logical/numerical/character/complex/raw
* **Lists**
  + Contains many different types of elements inside it like vectors, functions
    and even another list 
* **Matrices**
  + Two-dimensional rectangular data set
  
R DATATYPES
========================================================
* **Arrays**
  + Can be of any number of dimensions
* **Factors**
  + Created using a vector. It stores the vector along with the  distinct values of the elements in the vector as labels.
* **Data Frames**
  + Unlike a matrix in data frame each column can contain different modes of data. The first column can be numeric while the second column can be character and third column can be logical. 



Tibble - Modern reimagining of the data.frame (enhanced dataframe)
========================================================
left:50%
<br />
* data.frame: old fashion
* Lazy data.frame 
 + **TIBBLE !** 
 + Do less
 + Complain more
 + Easier to use

<br /><br />
Import data and convert it into modern format, make your life easier...

***
<br /><br />
![alt text](child-1463913.jpg)



Base R VS Tidyverse
========================================================
<br >
Why Tidyverse?
* Developed by Rstudio and Hadley Wickham
* Tidyverse is a superset of base R
* Features of Tidyverse
  + Same data type across functions
      - avoid having one function returns a dataframe and the another function requiring a matrix
      - no more constantly adjustment of data types
  + First allows piping
      - %>%, flow from one function to another
* spends up programming tremendously!


Core Tidyverse
========================================================
left:40%
<br ><br >
Tidyverse is not a package, it is a collection of packages: 
* **dplyr**
* **tidyr**
* **ggplot2**
* stringr
* purr
* tibble
* ...

***
<br /><br /><br /><br /><br />
![alt text](tidyverse.png)


CRUD Create, Retrieve, Update and Delete 增删改查
========================================================

|                   |R             | SAS                          | 
|------------------:|-------------:|----------------------------|
|**Create** **增**    | Assign: '<-'  <br/> 'mutate()'                      |data step <br/> newvar = expression;          |
|**Retrieve** **查**|Assign: '<-' <br/> Filter: 'filter()'               | libname <br/> set <br/> where clause |
|**Update** **改** |Assign: '<-' <br/> Mutate: 'mutate()'               | data step <br/> oldvar = expression; |
|**Delete** **删** |Select: 'select(!dropvar)' <br/> 'select(!c(dropvar1,dropvar2))' | drop dropvar1 dropvar2; | 
|**Sort** |Sort: 'arrange()' | proc sort | 


dplyr
========================================================
<br >
> ### Data manipulation
>> **tbl_df()**  
>> convert to tbl format  
>> **mutate()**  
>> adds new variables that are functions of existing variables  
>> **select()**  
>> picks variables based on their names.  
>> **filter()**  
>> picks cases based on their values.  
>> **summarise()**  
>> reduces multiple values down to a single summary.  
>> **arrange()**  
>> changes the ordering of the rows.  
>  **group_by()**  
>> allows you to perform any operation “by group”  
>  **Two-table verbs**


dplyr
========================================================
* **mutate()**



```r
library(tidyverse)
mydata <- mutate(Orange,Diameter=circumference/pi)
head(mydata,3)
```


```
  Tree age circumference  Diameter
1    1 118            30  9.549297
2    1 484            58 18.461973
3    1 664            87 27.692960
```

* **select()**

```r
mydata_sub <- select(mydata,Tree,Diameter)
head(mydata_sub,3)
```


```
  Tree  Diameter
1    1  9.549297
2    1 18.461973
3    1 27.692960
```

<span style="background-color: #CFDBDA;border-width:1px;border-color: #CFDBDA;border-style:solid;">
SAS equivalents:
</span>
+ newvar = expression;
+ oldvar = expression;
<br/>
+ keep var1 var2;

dplyr
========================================================
* **filter()**

```r
mydata_sub1 <-filter(mydata_sub,Diameter>10)
head(mydata_sub1,3)
```

```
  Tree Diameter
1    1 18.46197
2    1 27.69296
3    1 36.60564
```
* **summarise()** &  **group_by()**

```r
mydata_sub1 <- group_by(mydata_sub1,Tree)
mydata_sum <- summarise(mydata_sub1,Avg=mean(Diameter))
mydata_sum <- arrange(mydata_sum,Avg)
head(mydata_sum,3)
```

```
# A tibble: 3 × 2
  Tree    Avg
  <ord> <dbl>
1 3      33.3
2 1      35.4
3 5      39.7
```

<span style="background-color: #CFDBDA;border-width:1px;border-color: #CFDBDA;border-style:solid;">
SAS equivalents:
</span>
+ where clause;
<br/>
+ proc sort; by grpvar1 grpvar2; run;
+ proc means; proc sort;

dplyr
========================================================
<br >
* Piping:**%>%**
  + Passes object on left hand side as first argument (or . argument) of function on righthand side.
  + `x %>% f(y)` is the same as `f(x, y)`
  + `y %>% f(x, ., z)` is the same as `f(x, y, z )`
  + Re-write the code mentioned above:

```r
mydata_sum  <- 
  mutate(Orange,Diameter=circumference/pi) %>%
  select(Tree,Diameter) %>%
  filter(Diameter>10) %>%
  group_by(Tree) %>%
  summarise(Avg=mean(Diameter)) %>%
  arrange(Avg) 
```

<span style="background-color: #CFDBDA;border-width:1px;border-color: #CFDBDA;border-style:solid;">
SAS equivalents:
</span>
+ NO SUCH FEATURE! 

dplyr - Practise Part 1
========================================================
<br >
* Practise:
  + Example1.1 Set working directory and read advs.dpt from it.
      - **Hints**:`library(tidyverse)`  
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;`library(haven)`  
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;`setwd("~/data")`  
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;`advs<-read_xpt("advs.xpt")` 
  + Example1.2 List out all baseline values in advs and select columns USUBJID,PARAM,PARAMCD and AVAL,name the output data set as baseline 
      - **Hints**:  `filter`,  `select`,  `%>%`  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Single equal: Set equal  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Double equal: Test for equality
 

dplyr - Practise Part 1
========================================================
* Example 1.1

```r
setwd("~/data")
advs<-read_xpt("advs.xpt")
```


* Example 1.2

```r
baseline<-advs%>%
    filter(ABLFL=="Y")%>%
    select(USUBJID,PARAM,PARAMCD,AVAL)
head(baseline,8)
```


```
# A tibble: 8 × 4
  USUBJID     PARAM                           PARAMCD  AVAL
  <chr>       <chr>                           <chr>   <dbl>
1 01-701-1015 Diastolic Blood Pressure (mmHg) DIABP      56
2 01-701-1015 Diastolic Blood Pressure (mmHg) DIABP      51
3 01-701-1015 Diastolic Blood Pressure (mmHg) DIABP      61
4 01-701-1015 Pulse Rate (BEATS/MIN)          PULSE      56
5 01-701-1015 Pulse Rate (BEATS/MIN)          PULSE      59
6 01-701-1015 Pulse Rate (BEATS/MIN)          PULSE      59
7 01-701-1015 Systolic Blood Pressure (mmHg)  SYSBP     130
8 01-701-1015 Systolic Blood Pressure (mmHg)  SYSBP     121
```


dplyr
========================================================
<br >
**Two-table verbs**
  + **Mutating joins**  
  which add new variables to one table from matching rows in another.
  + **Binding**  
  which combine the observations in one dataset to the other as new rows  
  or new columns.
  + **Filtering joins**   
  which filter observations from one table based on whether or not   
  they match an observation in the other table.
  + **Set operations**  
  which combine the observations in the data sets as if they were set   
  elements.
  
dplyr
========================================================
<br >
* Mutating joins - similar in SAS
  + **left_join(x, y, by = )** Join matching rows from y to x.
  + **right_join(x, y, by = )** Join matching rows from x to y.
  + **inner_join(x, y, by = )** Join data. Retain only rows in both sets.
  + **full_join(x, y, by = )** Join data. Retain all values, all rows.

<span style="background-color: #CFDBDA;border-width:1px;border-color: #CFDBDA;border-style:solid;">
SAS equivalents:
</span>
+ IN option in MERGE statement:
  + merge x(in=a) y(in=b); by var1 var2;
  + if a; ** left join;
  + if b; ** right join;
  + if a and b; ** inner join;
  + if a or b; ** full join; ** or ignore this statement;

dplyr
========================================================
<br >
* Blinding
  + **bind_rows(x, z)** Append z to x as new rows.
  + **bind_cols(x, z)** Append z to x as new columns.  
*Caution: matches rows by position.*
<center>
![alt text](bind.png)
</center>

<span style="background-color: #CFDBDA;border-width:1px;border-color: #CFDBDA;border-style:solid;">
SAS equivalents:
</span>
+ set x z;
+ merge x z; ** no by statement, or if there are keys, use by statement;

dplyr
========================================================
<br >
* Filtering joins
  + **semi_join(x, y, by = "C1")** All rows in x that have a match in y.
  + **anti_join(x, y, by = "C1")** All rows in x that do not have a match in y.
<center>
![alt text](fjoin.png)
</center>

dplyr
========================================================
<br >
* Set operations
  + **intersect(x, z)** Rows that appear in both x and z.
  + **union(x, z)** Rows that appear in either or both x and z.
  + **setdiff(x, z)** Rows that appear in x but not z.
<center>
![alt text](setjoin.png)
</center>


      
dplyr - Practise Part 2
========================================================
<br >
* Practise:
  + Example 1.3.1 Filter all the observations with PARAMCD="HEIGHT" in advs and rename the  dataset as advs_h;
  + Example 1.3.2 Filter all the observations with PARAMCD="WEIGHT" in advs and rename the dataset as advs_w;
     - **Hints**:  'filter',  'select', 'mutate',  '%>%'
  + Example 1.3.3 Calculate BMI (Weight(kg)/Height(m) square), name the output dataset as advs_bmi
     - **Hints**:'left join' advs_h with advs_w
            - Weight was measured multiple times by visit
            - Height was measure only once at SCREENING 1 
            - square:`^2`
     

dplyr - Practise Part 2
========================================================
* Example 1.3.1

```r
advs_h<-advs%>%
    filter(PARAMCD=="HEIGHT")%>%
    mutate(HEIGHT=AVAL)%>%
    select(USUBJID,HEIGHT)
```
* Example 1.3.2

```r
advs_w<-advs%>%
  filter(PARAMCD=="WEIGHT")%>%
  mutate(WEIGHT=AVAL)
```
* Example 1.3.3

```r
bmi<-left_join(advs_w,advs_h,by="USUBJID")%>%
  mutate(BMI=WEIGHT/(HEIGHT/100)^2)
```




tidyr - tidy data
========================================================
<br >
> ### DATA reshaping
>> **~~gather()~~** **pivot_longer()**
>> takes multiple columns, and gathers them into key-value pairs: it makes “wide” data longer  
>> **~~spread()~~** **pivot_wider()**
>> takes two columns (key & value) and spreads in to multiple columns, it makes “long” data wider

<center>
![alt text](tran.png)
</center>


tidyr
========================================================
* **pivot_longer()**
  - Gather columns into key-value pairs.

```r
iris_sub <- iris[c(1,66,112),]
head(iris_sub,3)
iris_sub_t<-pivot_longer(iris_sub, !Species, names_to = "flower_att", values_to = "measurement")
head(iris_sub_t,7)
```


```
    Sepal.Length Sepal.Width Petal.Length Petal.Width    Species
1            5.1         3.5          1.4         0.2     setosa
66           6.7         3.1          4.4         1.4 versicolor
112          6.4         2.7          5.3         1.9  virginica
```

```
# A tibble: 7 × 3
  Species    flower_att   measurement
  <fct>      <chr>              <dbl>
1 setosa     Sepal.Length         5.1
2 setosa     Sepal.Width          3.5
3 setosa     Petal.Length         1.4
4 setosa     Petal.Width          0.2
5 versicolor Sepal.Length         6.7
6 versicolor Sepal.Width          3.1
7 versicolor Petal.Length         4.4
```

<span style="background-color: #CFDBDA;border-width:1px;border-color: #CFDBDA;border-style:solid;">
SAS equivalents:
</span>
+ proc transpose;

tidyr
========================================================
* **pivot_wider()**
  - Spread a key-value pair across multiple columns.

```r
pivot_wider(iris_sub_t,names_from=flower_att,values_from=measurement)
```


```
# A tibble: 3 × 5
  Species    Sepal.Length Sepal.Width Petal.Length Petal.Width
  <fct>             <dbl>       <dbl>        <dbl>       <dbl>
1 setosa              5.1         3.5          1.4         0.2
2 versicolor          6.7         3.1          4.4         1.4
3 virginica           6.4         2.7          5.3         1.9
```

<span style="background-color: #CFDBDA;border-width:1px;border-color: #CFDBDA;border-style:solid;">
SAS equivalents:
</span>
+ proc transpose;


tidyr - Practise 
========================================================
<br >
* Practise:
  + Example 1.4.1 Filter all baseline observations with PARAMCD="SYSBP" and PARAMCD="DIABP";
      - **hint**: 'or' in R: `|`
  + Example 1.4.2 Derive mean sysbp & mean diabp, name the output dataset as advs_m_bp
      - **hint**: 'group_by', 'summarise'
  + Example 1.4.3 Derive PP(pulse pressure:SYSBP-DIABP), name the output dataset as advs_pp;


tidyr - Practise 
========================================================
* Example 1.4.1 & Example 1.4.2

```r
advs_m_bp<-advs%>%
  filter(ABLFL=="Y")%>%
  filter(PARAMCD=="SYSBP" | PARAMCD=="DIABP")%>%
  select(USUBJID,PARAMCD,AVAL,VISIT)%>%
  group_by(USUBJID,PARAMCD) %>%
  summarise(Avg=mean(AVAL)) 
```
* Example 1.4.3

```r
advs_pp<-pivot_wider(advs_m_bp,names_from="PARAMCD",values_from="Avg")%>%
  mutate(PP=SYSBP-DIABP)
```



The End. Thanks!
========================================================
* [R learning resources](https://education.rstudio.com/teach/materials/)
<https://education.rstudio.com/teach/materials/>
+ [R for Data Science](https://r4ds.had.co.nz/)
<https://r4ds.had.co.nz/>
+ [Remaster the Tidyverse](https://github.com/rstudio-education/remaster-the-tidyverse)
<https://github.com/rstudio-education/remaster-the-tidyverse>
+ [STAT 545](https://stat545.com/)
<https://stat545.com/>
+ [tidyverse style guide](https://style.tidyverse.org/index.html)
<https://style.tidyverse.org/index.html>
+ [admiral (ADaM in R Asset Library)](https://github.com/pharmaverse/admiral)
+ API: (All kinds of GPTs, Big Language Models, use API)
 + [R API Tutorial: Getting Started with APIs in R | R-bloggers](https://www.r-bloggers.com/2020/02/r-api-tutorial-getting-started-with-apis-in-r/)
 + [Best practices for API packages (r-project.org)](https://cran.r-project.org/web/packages/httr/vignettes/api-packages.html)

+ More: <br/>
  renv<br/>
  version control: git<br/>
  project management<br/>
  if_else()<br/>
  case_when()<br/>


