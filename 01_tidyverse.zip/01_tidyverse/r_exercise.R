library(tidyverse)
mydata <- mutate(Orange, 
                 Diameter = circumference/pi)
head(mydata,3)
tail(mydata,3)
 
# install.packages("tidyverse")
# install.packages("haven")

mydata_sub <- select(mydata, Tree, Diameter)
head(mydata_sub)
head(mydata_sub1,3)

mydata_sub1 <- filter(mydata_sub, Diameter > 10)
head(mydata_sub1,3)

mydata_sub1 <- group_by(mydata_sub1, Tree)
mydata_sum <- summarise(mydata_sub1, 
                        Avg = mean(Diameter),
                        min = min(Diameter),
                        max = max(Diameter))
mydata_sum <- arrange(mydata_sum, Avg)
head(mydata_sum,3)

mydata_sum <- 
  mutate(Orange, Diameter = circumference/pi) %>%
  select(Tree, Diameter) %>%
  filter(Diameter > 10) %>%
  group_by(Tree) %>%
  summarise(Avg = mean(Diameter),
            min = min(Diameter),
            max = max(Diameter)) %>%
  arrange(Avg)
head(mydata_sum,3)
head(diamonds)
head(cars)
head(iris)

## example 1.1
setwd("~/data")
library(haven)
advs <- read_xpt("advs.xpt")
head(advs)

## example 1.2
baseline <- advs %>%
        filter(ABLFL == "Y") %>%
        select(USUBJID, PARAMCD, PARAM, AVAL)
head(baseline)


## Example 1.3.1
advs_h <- advs %>%
    filter(PARAMCD=="HEIGHT") %>%
    mutate(HEIGHT=AVAL) %>%
    select(USUBJID,HEIGHT)

## Example 1.3.2
advs_w <- advs %>%
  filter(PARAMCD=="WEIGHT") %>%
  mutate(WEIGHT=AVAL)


## Example 1.3.3
bmi <- left_join(advs_w,advs_h,by="USUBJID") %>%
  mutate(BMI=WEIGHT/(HEIGHT/100)^2)


##iris_sub <- iris[c(1,66,112),c("Sepal.Length", "Sepal.Width")]
iris_sub <- iris[c(1,66,112),]
head(iris_sub)


# pivot_longer, pivot_wider
# https://tidyr.tidyverse.org/reference/pivot_wider.html
iris_sub_t <- pivot_longer(iris_sub,c(Sepal.Length, Sepal.Width, Petal.Length, Petal.Width), names_to="flower_att", values_to="measurement") 
iris_sub_t <- pivot_longer(iris_sub,!Species, names_to="flower_att", values_to="measurement") 
                     

iris_sub_w <- pivot_wider(iris_sub_t,names_from="flower_att", values_from="measurement") 

## example 1.4.1
advs_m_bp<-advs%>%
  filter(ABLFL=="Y")%>%
  filter(PARAMCD=="SYSBP" | PARAMCD=="DIABP")%>%
  select(USUBJID,PARAMCD,AVAL,VISIT)%>%
  group_by(USUBJID,PARAMCD) %>%
  summarise(Avg=mean(AVAL)) 
  ##summarise(Avg=mean(AVAL), std=sd(AVAL),min=min(AVAL),max=max(AVAL)) 

## example 1.4.3
advs_pp<-pivot_wider(advs_m_bp,names_from="PARAMCD",values_from="Avg")%>%
  mutate(PP=SYSBP-DIABP)


