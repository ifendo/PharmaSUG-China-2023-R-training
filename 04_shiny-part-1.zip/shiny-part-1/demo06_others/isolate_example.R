library(shiny)

ui <- fluidPage(
  textInput('title', "Plot title"),
  sliderInput('num', "Choose a number", value=25, min=10, max=50),
  plotOutput('hist')
)


server <- function(input, output, session) {
  # output$hist <- renderPlot({
  #   hist(rnorm(input$num), main = isolate(input$title))
  # })  
  
  observeEvent(input$num, {
    output$hist <- renderPlot({
      hist(rnorm(input$num), main = input$title)
    })
    
  })
  

}

shinyApp(ui, server)
