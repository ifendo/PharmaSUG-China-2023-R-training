library(shiny)
library(clipr) # copy to clipboard

ui <- fluidPage(
  h3("Convertion between Windows/Linux path"),

  selectInput('toformat', "Selection:", choices = c("Win to Linux", "Linux to Win")),
  textInput('in_path', "Input Path:", width = "80%"),
  textOutput('out_path'),
  actionButton('copy', "Copy to Clipboard!")
)

server <- function(input, output, session) {

  converted <- reactive({
    req(input$in_path)
    if (input$toformat == "Win to Linux") gsub("\\", "/", input$in_path, fixed = TRUE)
    else if (input$toformat == "Linux to Win") gsub("/", "\\", input$in_path, fixed = TRUE)
  })

  output$out_path <- renderText({
    converted()
  })
  
  observeEvent(input$copy, {
    write_clip(converted(), allow_non_interactive = TRUE)
  })
}

shinyApp(ui, server)